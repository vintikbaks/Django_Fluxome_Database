from django.contrib import admin
from .models import Flux, Flux2

# Register your models here.
admin.site.register(Flux)
admin.site.register(Flux2)