from django.apps import AppConfig


class QueriesConfig(AppConfig):
    name = 'queries'
